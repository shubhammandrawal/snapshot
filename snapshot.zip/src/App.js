import './App.css';
import Images from './components/Image/Image';
import Search from './components/Search/Search';

function App() {
  return <>
    <Search />
  </>
}

export default App;
